package Question4_5;

public class IntWrapper {
	public IntWrapper(int m) {
		data = m;
	}
	public int data;
}
