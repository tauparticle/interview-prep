package Question2_5;

import CtCILibrary.LinkedListNode;

public class PartialSum {
	public LinkedListNode sum = null;
	public int carry = 0;
}
