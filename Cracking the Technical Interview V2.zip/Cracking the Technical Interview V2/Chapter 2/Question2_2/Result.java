package Question2_2;

import CtCILibrary.*;

public class Result {
	public LinkedListNode node;
	public int count;
	public Result(LinkedListNode n, int c) {
		node = n;
		count = c;
	}
}
