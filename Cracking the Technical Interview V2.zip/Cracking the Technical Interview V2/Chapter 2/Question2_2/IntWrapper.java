package Question2_2;

public class IntWrapper {
	public int value = 0;
}
