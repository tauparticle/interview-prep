package Question17_13;

public class BiNode {
	public BiNode node1;
	public BiNode node2;
	public int data; 
	public BiNode(int d) {
		data = d;
	}
}
