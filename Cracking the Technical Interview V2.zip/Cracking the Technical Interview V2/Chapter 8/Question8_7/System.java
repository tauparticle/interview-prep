package Question8_7;

public class System {

}
