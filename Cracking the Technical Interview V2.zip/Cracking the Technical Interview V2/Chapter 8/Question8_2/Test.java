package Question8_2;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CallHandler ch = CallHandler.getInstance();
	}

}
